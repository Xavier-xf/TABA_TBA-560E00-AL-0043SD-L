#undef CONFIG_LPQ
